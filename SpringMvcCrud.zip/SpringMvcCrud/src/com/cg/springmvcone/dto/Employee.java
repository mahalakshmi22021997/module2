package com.cg.springmvcone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employee3")
public class Employee {

	@Id
	/*@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="emp_seq")
	@SequenceGenerator(name="emp_seq",sequenceName="emp_seq_eid")
	@Column(name="empId")*/
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int empId;
	
	@Column(name="empName")
	@NotEmpty(message="Name should not be null")
	private String empName;
	
	@Column(name="empDesignation")
	private String empDesignation;
	
	@Column(name="empSalary")
	@NotNull(message="slary should not blank")
	private double empSalary;
	
	@Column(name="empGender")
	private String empGender;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpGender() {
		return empGender;
	}

	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empDesignation=" + empDesignation + ", empSalary="
				+ empSalary + ", empGender=" + empGender + "]";
	}
	
	
	
	
	
}
