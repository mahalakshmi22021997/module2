package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcone.dto.Employee;

@Repository("employeedao")
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public int addEmployeeData(Employee emp) {
		// TODO Auto-generated method stub
		entitymanager.persist(emp);
		entitymanager.flush();
		return emp.getEmpId();
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		Query queryLi=entitymanager.createQuery("FROM Employee"); //class name Employee
		List<Employee> list=queryLi.getResultList();
		return list;
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		Query queryDel=entitymanager.createQuery(" delete FROM Employee WHERE empId=:eid");
		queryDel.setParameter("eid", empId);
		queryDel.executeUpdate();
		

	}

    @Override
    public boolean updateEmployee(Employee emp) {
           boolean result=false;
           int id=emp.getEmpId();
           Employee employee = entitymanager.find(Employee.class,id);
           entitymanager.merge(emp);
           result=true;
           return result;
    }

	@Override
    public Employee searchEmployee(int id) {
           // TODO Auto-generated method stub
           Employee emp = null;
         //  Query querySearch = entitymanager.createQuery("From Employee");
           emp = entitymanager.find(Employee.class, id);
           return emp;
    }





}
